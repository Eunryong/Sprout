import copy
import random

import torch

from server.learning.checkpoints import load, save
from server.learning.dataset import Example, collate, slot_logits
from server.learning.learner import Learner, OnlineCfg
from server.learning.model import ModelCfg, build_model, n_params
from server.learning.policy import slot_probs
from server.world.scenegen import make_situation
from server.world.situation import answer_slots, build_observation


def make_ex(seed, i=0, kind="cup"):
    rng = random.Random(seed)
    sit, objs = make_situation(rng, "s", 0, "bobo", "NAME_00", kind)
    o = {x.id: x for x in objs}
    return Example(id=f"e{seed}-{i}", day=1, source="show", obs=build_observation(sit, o),
                   target_slot=answer_slots(sit, o)[0])


def test_mask_allows_all_existing_slots():
    m = build_model(ModelCfg())
    for seed in range(10):
        ex = make_ex(seed)
        ids, lengths, n_slots, _, _ = collate([ex])
        lg = slot_logits(m, ids, lengths, n_slots)[0]
        n = len(ex.obs.slots)
        assert torch.isfinite(lg[:n]).all() and torch.isinf(lg[n:]).all()
        p = slot_probs(m, ex.obs)
        assert len(p) == n and abs(sum(p) - 1) < 1e-5


def test_learn_changes_weights_and_lowers_loss():
    m = build_model(ModelCfg())
    before = copy.deepcopy(m.state_dict())
    ex = make_ex(1)
    rep = Learner(m, OnlineCfg()).learn(ex, [ex], random.Random(0))
    assert rep.loss_after < rep.loss_before
    assert any(not torch.equal(before[k], v) for k, v in m.state_dict().items())


def test_ckpt_roundtrip_and_immutable(tmp_path):
    m = build_model(ModelCfg())
    p = tmp_path / "ckpt_000.pt"
    save(m, p)
    ex = make_ex(2)
    Learner(m, OnlineCfg()).learn(ex, [ex], random.Random(0))
    m0, _ = load(p)
    assert slot_probs(m0, ex.obs) != slot_probs(m, ex.obs)  # ckpt_000 untouched by later learning
    try:
        save(m, p, overwrite=False)
        raise AssertionError("expected FileExistsError")
    except FileExistsError:
        pass


def test_size_report(capsys):
    print("params", n_params(build_model(ModelCfg())))


def test_redraw_keeps_target_and_never_adds_a_second_target_kind():
    from server.learning.dataset import augment, redraw_distractors
    rng = random.Random(0)
    for seed in range(60):
        ex = make_ex(seed)
        out = redraw_distractors(ex, rng)
        t = ex.target_slot
        assert out.target_slot == t and out.obs.slots[t] == ex.obs.slots[t]
        tgt = out.obs.slots[t]
        assert len(out.obs.slots) == len(ex.obs.slots)
        assert all((s.shape, s.material) != (tgt.shape, tgt.material) for i, s in enumerate(out.obs.slots) if i != t)
        aug = augment(ex, rng, 1.0)
        assert aug.obs.slots[aug.target_slot] == ex.obs.slots[t]  # target attributes survive shuffle + redraw
