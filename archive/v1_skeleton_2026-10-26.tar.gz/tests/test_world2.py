import copy
import random

import torch

from server.learning.codec2 import (
    MAX_LEN2, VOCAB2, Example2, augment2, collate2, encode2, make_quiz2, option_logits, option_probs, redraw_options,
    score2, shuffle_options, weighted_ce2,
)
from server.learning.learner import Learner, OnlineCfg
from server.learning.model import ModelCfg, build_model
from server.world.world2 import (
    NEEDS, REQUEST_KINDS, TAGS, make_situation2, obs_hash, observation, optimal, option_value, values, Obj2,
)

TOPICS = [(["THIRSTY"], None, None, None), (["FLOOR_WET"], None, None, None), (["DARK"], None, None, None),
          (["COLD"], None, None, None), (["VISITOR"], None, None, None), (["COLD", "DARK"], None, None, None)] + [
    (["REQUEST"], f"w{i}", f"NAME_0{i}", k) for i, k in enumerate(REQUEST_KINDS)]


def sits(n=40):
    rng = random.Random(0)
    for tags, w, tok, kind in TOPICS:
        for i in range(n):
            yield make_situation2(rng, tags, f"s{i}", w, tok, kind)


def obj(kind, shape="x", material="y"):
    return Obj2(kind=kind, color="red", shape=shape, size="big", material=material)


def test_rules_table():
    assert option_value(["THIRSTY"], None, "DRINK", obj("cup")) == 2
    assert option_value(["THIRSTY"], None, "DRINK", obj("spoon")) == 0
    assert option_value(["FLOOR_WET"], None, "WIPE", obj("paper")) == 1
    assert option_value(["COLD"], None, "COVER", obj("cloth")) == 1
    assert option_value(["DARK"], None, "WAIT", None) == 0 and option_value(["COLD"], None, "WAIT", None) == -1
    assert option_value(["REQUEST"], "ball", "FETCH", obj("ball")) == 2
    assert option_value(["REQUEST"], "ball", "FETCH", obj("cup")) == 0
    assert option_value(["COLD", "DARK"], None, "LIGHT", obj("flashlight")) == 2  # either problem can be solved
    assert option_value(["COLD", "DARK"], None, "WAIT", None) == -1


def test_generator_invariants():
    for s in sits():
        v = values(s)
        assert 3 <= len(s.options) <= 5 and len(set(s.options)) == len(s.options)
        assert max(v) == 2 and min(v) < 2 and optimal(s)
        assert all((o.target is None) == (o.verb == "WAIT") or o.verb != "WAIT" for o in s.options)
        for t in s.tags:
            if t != "REQUEST":  # the right thing is always on the table
                verb, kind = NEEDS[t]
                assert any(o.verb == verb and s.objects[o.target].kind == kind for o in s.options if o.target is not None)
        # there is at least one trap of each type for non-request problems
        if s.tags != ["REQUEST"]:
            assert any(x == 0 for x in v if True) or min(v) < 2


def test_child_observation_has_no_kind_value_or_narration():
    for s in list(sits(10))[:30]:
        d = observation(s).model_dump()
        assert set(d) == {"tags", "name_token", "options"}
        for o in d["options"]:
            assert set(o) == {"verb", "target"}
            assert o["target"] is None or set(o["target"]) == {"color", "shape", "size", "material"}


def test_hash_is_order_insensitive_and_forbidden_respected():
    s = next(sits(1))
    o = observation(s)
    rev = o.model_copy(update={"options": list(reversed(o.options))})
    assert obs_hash(o) == obs_hash(rev)
    rng = random.Random(1)
    for _ in range(50):
        t = make_situation2(rng, ["THIRSTY"], "x", forbidden={obs_hash(o)})
        assert obs_hash(observation(t)) != obs_hash(o)


def test_encoding_and_masking():
    m = build_model(ModelCfg(vocab_size=len(VOCAB2), max_len=MAX_LEN2))
    for s in sits(8):
        ex = Example2(id="e", day=1, source="show", obs=observation(s), target_slot=optimal(s)[0])
        ids = encode2(ex.obs)
        assert len(ids) <= MAX_LEN2 and max(ids) < len(VOCAB2)
        a, b, n, _, _ = collate2([ex])
        lg = option_logits(m, a, b, n)[0]
        k = len(ex.obs.options)
        assert torch.isfinite(lg[:k]).all() and torch.isinf(lg[k:]).all()
        p = option_probs(m, ex.obs)
        assert len(p) == k and abs(sum(p) - 1) < 1e-5


def test_augmentation_keeps_the_taught_option():
    rng = random.Random(0)
    for s in sits(15):
        ex = Example2(id="e", day=1, source="show", obs=observation(s), target_slot=optimal(s)[0])
        chosen = ex.obs.options[ex.target_slot]
        for p in (0.0, 1.0):
            a = augment2(ex, rng, p)
            assert a.obs.options[a.target_slot] == chosen and len(a.obs.options) == len(ex.obs.options)
        r = redraw_options(ex, rng)
        for i, o in enumerate(r.obs.options):
            if i != ex.target_slot:
                assert o != chosen  # never a duplicate of what the player chose
        sh = shuffle_options(ex, rng)
        assert sorted(map(repr, sh.obs.options)) == sorted(map(repr, ex.obs.options))


def test_learning_lowers_loss_and_quiz_scoring_runs():
    m = build_model(ModelCfg(vocab_size=len(VOCAB2), max_len=MAX_LEN2, seed=1))
    before = copy.deepcopy(m.state_dict())
    s = next(sits(1))
    ex = Example2(id="e0", day=1, source="show", obs=observation(s), target_slot=optimal(s)[0])
    def avg_loss(model):  # average over option orders: one order can look good by luck at initialisation
        r = random.Random(5)
        with torch.no_grad():
            return sum(weighted_ce2(model, [shuffle_options(ex, r)]).item() for _ in range(40)) / 40
    start = avg_loss(m)
    Learner(m, OnlineCfg(redraw=0.0), ce_fn=weighted_ce2, aug_fn=augment2).learn(ex, [ex], random.Random(0), steps=240)
    assert avg_loss(m) < start * 0.3
    assert any(not torch.equal(before[k], v) for k, v in m.state_dict().items())
    quiz = make_quiz2(random.Random(3), TOPICS[:3], 5)
    sc = score2(m, quiz)
    assert sc["n"] == 15 and 0 <= sc["optimal"] <= 1 and sc["random"] > 0
    assert len({q.hash for q in quiz}) == 15
