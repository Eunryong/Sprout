import random

import torch

from server.learning.dataset import Example
from server.learning.learner import weighted_ce
from server.learning.model import ModelCfg, build_model
from server.learning.probe import probe_word, pulls, top_cues
from server.world.catalog import COLORS, KINDS
from server.world.situation import Observation, SlotView

PAIRS = [(k.shape, k.material) for k in KINDS.values()]


def rule_examples(rule: str, n: int, rng: random.Random):
    """Hand-made worlds where the 'word' (NAME_00) means ONE attribute, so the probe has a known answer."""
    out = []
    for i in range(n):
        slots = []
        for _ in range(3):
            shape, mat = rng.choice(PAIRS)
            slots.append(SlotView(color=rng.choice(COLORS), shape=shape, size=rng.choice(["small", "big"]), material=mat))
        t = rng.randrange(3)
        s = slots[t]
        if rule == "red":
            slots = [x.model_copy(update={"color": rng.choice(["blue", "green", "yellow"])}) for x in slots]
            slots[t] = s.model_copy(update={"color": "red"})
        else:  # "cylinder"
            slots = [x if x.shape != "cylinder" else SlotView(color=x.color, shape="sphere", size=x.size, material="rubber") for x in slots]
            slots[t] = SlotView(color=s.color, shape="cylinder", size=s.size, material="ceramic")
        out.append(Example(id=f"r{i}", day=1, source="show", obs=Observation(name_token="NAME_00", slots=slots), target_slot=t))
    return out


def train(rule: str, seed=0, steps=250):
    rng = random.Random(seed)
    model = build_model(ModelCfg(seed=seed))
    data = rule_examples(rule, 200, rng)
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3)
    model.train()
    for _ in range(steps):
        loss = weighted_ce(model, rng.sample(data, 32))
        opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    return model


def test_untrained_model_is_indifferent():
    pr = pulls(probe_word(build_model(ModelCfg(seed=0)), "NAME_00", random.Random(1), n=40))
    assert max(pr.values()) < 0.3  # near 0.5 everywhere (small residual from random init)


def test_probe_finds_a_color_rule_and_a_shape_rule():
    m_red = train("red")
    prefs = probe_word(m_red, "NAME_00", random.Random(1), n=40)
    assert prefs["color"]["red"] > 0.8 and pulls(prefs)["color"] > pulls(prefs)["size"] + 0.2
    assert top_cues(prefs, 1)[0][:2] == ("color", "red")
    m_cyl = train("cylinder")
    prefs = probe_word(m_cyl, "NAME_00", random.Random(1), n=40)
    assert prefs["shape"]["cylinder"] > 0.8 and pulls(prefs)["shape"] > pulls(prefs)["color"] + 0.1


def test_probe_is_deterministic_and_does_not_change_the_model():
    m = build_model(ModelCfg(seed=3))
    before = {k: v.clone() for k, v in m.state_dict().items()}
    a = probe_word(m, "NAME_01", random.Random(5), n=10)
    b = probe_word(m, "NAME_01", random.Random(5), n=10)
    assert a == b and all(torch.equal(before[k], v) for k, v in m.state_dict().items())
