import hashlib
import random

import pytest
import torch

from server.agents.client import ClientError
from server.game.autoplay import play_day
from server.game.session import Session
from server.learning.evaluator import score
from server.learning.policy import slot_probs
from server.world.events import RuleError
from server.world.situation import canonical_hash
from server.world.state import Phase


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def new(tmp_path, seed=0, name="s", **kw):
    return Session.new(tmp_path / name, seed=seed, **kw)


def to_situation(s, pick=0):
    s.draw_cards()
    s.pick_card(pick)


def wrong_slot(s):
    ans = s.debug_answers()[0]
    return (ans + 1) % len(s.state.current.scene)


def test_quiz_not_in_train_and_ckpt0_immutable_and_weights_move(tmp_path):
    s = new(tmp_path, seed=3)
    h0 = sha(s.save.ckpt0)
    before = {k: v.clone() for k, v in s.model.state_dict().items()}
    rng = random.Random(0)
    for _ in range(2):
        play_day(s, rng)
    quiz_hashes = {q.hash for q in s.quiz}
    train_hashes = {canonical_hash(e.obs) for e in s.buffer}
    assert len(s.buffer) == 12 and not (quiz_hashes & train_hashes)
    assert sha(s.save.ckpt0) == h0
    assert any(not torch.equal(before[k], v) for k, v in s.model.state_dict().items())
    n_learned = sum(e.type.value == "learned" for e in s.engine.log)
    assert n_learned == len(s.buffer)


def test_reset_forgets(tmp_path):
    s = new(tmp_path, seed=4)
    rng = random.Random(1)
    for _ in range(5):
        play_day(s, rng)
    known = {s.state.words[w] for w in s.state.picked_words}
    pool = [q for q in s.quiz if q.obs.name_token in known]
    trained, reset = score(s.model, pool), score(s.model0, pool)
    assert trained["p_correct"] > reset["p_correct"] + 0.25, (trained, reset)


def test_resume_is_identical_and_continues(tmp_path):
    s = new(tmp_path, seed=5)
    rng = random.Random(2)
    play_day(s, rng)
    to_situation(s)
    s.show(s.debug_answers()[0])  # leave the day half done
    q = s.quiz[0].obs
    p_before, state_before, n = slot_probs(s.model, q), s.state.model_copy(deep=True), len(s.buffer)
    s2 = Session.load(tmp_path / "s")
    assert not s2.warnings
    assert s2.state == state_before and len(s2.buffer) == n
    assert slot_probs(s2.model, q) == p_before
    # the optimizer state came back too: both sessions take the same next step
    s.draw_cards(); s2.draw_cards()
    assert s.state.cards == s2.state.cards
    s.pick_card(0); s2.pick_card(0)
    a = s.debug_answers()[0]
    r1, r2 = s.show(a), s2.show(a)
    assert r1.learn.loss_after == pytest.approx(r2.learn.loss_after, rel=1e-5)
    play_day(s2, rng)  # and the loaded game can be played on


def test_session_idempotent_show(tmp_path):
    s = new(tmp_path, seed=6)
    to_situation(s)
    a = s.debug_answers()[0]
    assert not s.show(a, action_id="x1").duplicate
    n = len(s.buffer)
    assert s.show(a, action_id="x1").duplicate
    assert len(s.buffer) == n and s.state.situations_done == 1


def test_wrong_show_learned_as_is(tmp_path):
    s = new(tmp_path, seed=7)
    to_situation(s)
    w = wrong_slot(s)
    r = s.show(w)
    ex = s.buffer[-1]
    assert ex.target_slot == w and ex.was_right is False and ex.source == "show"
    assert "not the" in r.narration
    assert s.save.read_examples()[-1] == ex


def test_skip_and_unanswered_try_make_no_example(tmp_path):
    s = new(tmp_path, seed=8)
    to_situation(s)
    s.skip()
    to_situation(s)
    s.try_child()
    s.skip()  # tried, no feedback -> skip
    assert s.buffer == [] and s.state.situations_done == 2
    assert not any(e.type.value == "learned" for e in s.engine.log)


def test_try_praise_correct_flow_and_weights(tmp_path):
    s = new(tmp_path, seed=9)
    seen = set()
    rng = random.Random(0)
    for _ in range(40):
        if s.state.phase == Phase.EVENING:
            s.end_day()
        to_situation(s, rng.randrange(2))
        r = s.try_child()
        if r.was_right:
            s.praise(); seen.add("praise")
        else:
            with pytest.raises(RuleError):
                s.praise()
            s.correct(s.debug_answers()[0]); seen.add("correct")
        if seen == {"praise", "correct"}:
            break
    by = {e.source: e for e in s.buffer}
    assert by["praise"].weight == 0.5 and by["correct"].weight == 1.0 and by["correct"].rejected_slot is not None
    assert by["praise"].target_slot is not None


def test_evening_gating_and_day_rollover(tmp_path):
    s = new(tmp_path, seed=10)
    with pytest.raises(RuleError):
        s.end_day()
    rng = random.Random(3)
    r = play_day(s, rng)
    assert r["day"] == 1 and s.state.day == 2 and s.state.phase == Phase.CARDS
    assert s.save.day_ckpt(1).exists()
    assert r["n"] <= 8 and 0 <= r["p_correct"] <= 1


def test_director_failure_does_not_stop_the_game(tmp_path):
    class Down:
        name = "down"
        def complete_json(self, **kw):
            raise ClientError("api down")
    s = new(tmp_path, seed=11, client=Down())
    to_situation(s)
    assert s.director.last_source == "template" and "api down" in s.director.last_error
    s.show(s.debug_answers()[0])


def test_views_never_mix_child_and_player_knowledge(tmp_path):
    s = new(tmp_path, seed=12)
    to_situation(s)
    v = s.view()
    assert v.cards and all(c.kind_label for c in v.cards) and v.hint  # player sees kind labels + first-use hint
    s.show(s.debug_answers()[0])
    to_situation(s)
    assert s.view().hint is None or s.state.current_first


def test_mind_report_and_snapshot_compare(tmp_path):
    s = new(tmp_path, seed=13)
    assert s.mind() == {}  # nothing met yet
    rng = random.Random(0)
    play_day(s, rng)
    play_day(s, rng)
    m = s.mind(compare_day=1)
    assert m and all(set(e["pulls"]) == {"color", "shape", "size", "material"} for e in m.values())
    assert all("before" in e for e in m.values()) and s.mind() == s.mind()  # deterministic
    w = next(iter(m.values()))
    assert 0 <= w["accuracy"] <= 1 and all(0.5 < p <= 1 for _, _, p in w["cues"])
    assert m == s.mind(compare_day=1)
