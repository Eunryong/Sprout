import random

from server.learning.tokenizer import encode
from server.learning.vocab import MAX_LEN, TOK, VOCAB
from server.world.scenegen import make_situation
from server.world.situation import answer_slots, build_observation, canonical_hash


def _scene(seed=0, **kw):
    rng = random.Random(seed)
    sit, objs = make_situation(rng, "s1", 0, "bobo", "NAME_00", "cup", **kw)
    return sit, {o.id: o for o in objs}


def test_child_obs_no_leak():
    sit, objs = _scene()
    obs = build_observation(sit, objs)
    dumped = obs.model_dump_json()
    for o in objs.values():
        assert o.id not in dumped
    # "paper" is also a legitimate material value, so check field names, not kind strings
    assert set(obs.model_dump()) == {"request", "name_token", "slots"}
    assert all(set(s) == {"color", "shape", "size", "material"} for s in obs.model_dump()["slots"])


def test_exactly_one_answer_and_tokenizes():
    for seed in range(50):
        sit, objs = _scene(seed)
        assert len(answer_slots(sit, objs)) == 1
        ids = encode(build_observation(sit, objs))
        assert len(ids) <= MAX_LEN and all(0 <= i < len(VOCAB) for i in ids)
        assert ids[-1] == TOK["ACT_PICK"]


def test_forbidden_hashes_respected():
    sit, objs = _scene(1)
    h = canonical_hash(build_observation(sit, objs))
    for seed in range(100):
        rng = random.Random(seed)
        s2, o2 = make_situation(rng, "x", 0, "bobo", "NAME_00", "cup", forbidden={h})
        assert canonical_hash(build_observation(s2, {o.id: o for o in o2})) != h
