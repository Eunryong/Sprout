import random

import pytest

from server.world.engine import Engine
from server.world.events import (
    Correct, EndDay, OfferCards, PickCard, Praise, RecordQuiz, RuleError, Show, Skip, Try,
)
from server.world.scenegen import make_situation
from server.world.state import Phase, fold


def offer(e: Engine, rng, aid, words=(("bobo", "cup"), ("mimi", "ball"))):
    sits, objs = [], []
    n = len(e.state.objects)
    for k, (w, kind) in enumerate(words):
        s, o = make_situation(rng, f"sit_{aid}_{k}", n, w, "", kind)
        n += len(o)
        sits.append(s)
        objs += o
    return e.submit(OfferCards(action_id=aid, situations=sits, objects=objs))


def start(e, rng, aid="o1", pick=0):
    offer(e, rng, aid)
    e.submit(PickCard(action_id=f"p-{aid}", index=pick))


def answer(e):
    from server.world.state import current_answers
    return current_answers(e.state)[0]


def test_idempotent():
    e, rng = Engine(), random.Random(0)
    start(e, rng)
    cmd = Show(action_id="s1", slot=answer(e))
    assert len(e.submit(cmd)) == 1
    n = len(e.log)
    assert e.submit(cmd) == [] and len(e.log) == n
    assert e.state.situations_done == 1


def test_fold_roundtrip():
    e, rng = Engine(per_day=2), random.Random(1)
    for i in range(2):
        start(e, rng, f"o{i}")
        e.submit(Show(action_id=f"s{i}", slot=answer(e)))
    assert e.state.phase == Phase.EVENING
    e.submit(RecordQuiz(action_id="q", result={"score": 0.5}))
    e.submit(EndDay(action_id="end"))
    assert e.state.day == 2
    rebuilt = Engine(log=[ev.model_copy() for ev in e.log])
    assert rebuilt.state == e.state == fold(e.log)
    # survives a JSON round trip too
    from server.world.events import Event
    again = fold([Event.model_validate_json(ev.model_dump_json()) for ev in e.log])
    assert again == e.state


def test_rule_errors():
    e, rng = Engine(per_day=2), random.Random(2)
    with pytest.raises(RuleError) as x:
        e.submit(PickCard(action_id="a", index=0))
    assert x.value.code == "no_cards"
    with pytest.raises(RuleError) as x:
        e.submit(Show(action_id="b", slot=0))
    assert x.value.code == "wrong_phase"
    offer(e, rng, "o1")
    with pytest.raises(RuleError) as x:
        e.submit(PickCard(action_id="c", index=5))
    assert x.value.code == "bad_pick"
    e.submit(PickCard(action_id="c2", index=0))
    with pytest.raises(RuleError) as x:
        e.submit(Show(action_id="d", slot=9))
    assert x.value.code == "bad_slot"
    with pytest.raises(RuleError) as x:
        e.submit(Praise(action_id="e"))
    assert x.value.code == "no_try"
    right = answer(e)
    wrong = (right + 1) % len(e.state.current.scene)
    e.submit(Try(action_id="t1", slot=right))
    with pytest.raises(RuleError) as x:
        e.submit(Correct(action_id="f", slot=wrong))
    assert x.value.code == "tried_right"
    with pytest.raises(RuleError) as x:
        e.submit(Show(action_id="g", slot=right))
    assert x.value.code == "already_tried"
    e.submit(Praise(action_id="h"))  # resolves the situation
    with pytest.raises(RuleError):
        e.submit(Skip(action_id="i"))  # nothing in progress now
    # evening gating
    start(e, rng, "o2")
    e.submit(Try(action_id="t2", slot=(answer(e) + 1) % len(e.state.current.scene)))
    with pytest.raises(RuleError) as x:
        e.submit(Praise(action_id="j"))
    assert x.value.code == "tried_wrong"
    e.submit(Correct(action_id="k", slot=answer(e)))
    assert e.state.phase == Phase.EVENING
    with pytest.raises(RuleError) as x:
        e.submit(EndDay(action_id="l"))
    assert x.value.code == "quiz_needed"


def test_wrong_show_is_allowed_and_flagged():
    e, rng = Engine(), random.Random(3)
    start(e, rng)
    wrong = (answer(e) + 1) % len(e.state.current.scene)
    ev = e.submit(Show(action_id="s", slot=wrong))[0]
    assert ev.payload == {"slot": wrong, "was_right": False}


def test_bad_offers_rejected():
    e, rng = Engine(), random.Random(4)
    with pytest.raises(RuleError):
        offer(e, rng, "o", words=(("bobo", "cup"), ("bobo", "ball")))  # same word, two kinds
    assert e.state.cards is None
    with pytest.raises(RuleError):
        offer(e, rng, "o2", words=(("bobo", "cup"), ("mimi", "cup")))  # same kind, two words


def test_fixed_tokens_and_first_use_flag():
    e, rng = Engine(), random.Random(5)
    n = 0
    sits, objs = [], []
    for k, (w, kind, tok) in enumerate([("bobo", "cup", "NAME_07"), ("mimi", "ball", "NAME_02")]):
        s, o = make_situation(rng, f"s{k}", n, w, tok, kind)
        n += len(o); sits.append(s); objs += o
    e.submit(OfferCards(action_id="o", situations=sits, objects=objs))
    assert e.state.words == {"bobo": "NAME_07", "mimi": "NAME_02"}
    e.submit(PickCard(action_id="p", index=0))
    assert e.state.current_first is True
    e.submit(Skip(action_id="s"))
    sits2, objs2 = [], []
    for k, (w, kind, tok) in enumerate([("bobo", "cup", ""), ("mimi", "ball", "NAME_09")]):
        s, o = make_situation(rng, f"t{k}", n, w, tok, kind)
        n += len(o); sits2.append(s); objs2 += o
    with pytest.raises(RuleError):  # mimi already has NAME_02
        e.submit(OfferCards(action_id="o2", situations=sits2, objects=objs2))
