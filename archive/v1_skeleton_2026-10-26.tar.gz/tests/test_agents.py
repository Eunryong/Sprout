import ast
import json
import random
from pathlib import Path

import pytest

from server.agents.client import AllClientsFailed, ClientError, MockClient, RouterClient
from server.agents.director import DirectorAgent, ProposalError, build_offer, mock_director_handler, template_proposal
from server.agents.narrator import intro, outcome, refs_ok
from server.agents.schemas import CardProposal, DirectorProposal, ObjSpec
from server.world.engine import Engine
from server.world.events import OfferCards

WM = {"cup": ("bobo", "NAME_00"), "cloth": ("mimi", "NAME_01"), "paper": ("tata", "NAME_02"), "ball": ("lulu", "NAME_03")}


class Boom:
    name = "boom"

    def complete_json(self, **kw):
        raise ClientError("down")


class Fixed:
    def __init__(self, name, prop):
        self.name, self.prop = name, prop

    def complete_json(self, **kw):
        return self.prop


def good():
    return template_proposal({}, random.Random(0), set(), WM)


def test_router_fallback_and_all_fail():
    r = RouterClient([Boom(), Fixed("second", {"ok": 1})])
    assert r.complete_json(agent="x", system="", user="{}", schema=dict) == {"ok": 1}
    assert r.last_used == "second" and len(r.errors) == 1
    with pytest.raises(AllClientsFailed):
        RouterClient([Boom(), Boom()]).complete_json(agent="x", system="", user="{}", schema=dict)


def bad_proposals():
    g = good()
    unknown = g.model_copy(deep=True); unknown.cards[0].kind = "dragon"
    twin = DirectorProposal(cards=[g.cards[0], g.cards[0]])
    no_target = g.model_copy(deep=True)
    no_target.cards[0].objects = [o for o in no_target.cards[0].objects if o.kind != no_target.cards[0].kind] + [
        ObjSpec(kind="paper" if no_target.cards[0].kind != "paper" else "ball", color="red", size="big")] * 0
    two_targets = g.model_copy(deep=True)
    c = two_targets.cards[0]
    c.objects = c.objects + [ObjSpec(kind=c.kind, color="red", size="big")]
    too_few = g.model_copy(deep=True); too_few.cards[0].objects = too_few.cards[0].objects[:2]
    return [unknown, twin, no_target, two_targets, too_few, DirectorProposal(cards=g.cards[:1])]


def test_build_offer_rejects_bad_proposals_and_engine_accepts_good():
    for bad in bad_proposals():
        with pytest.raises(ProposalError):
            build_offer(bad, WM, 0, set())
    sits, objs = build_offer(good(), WM, 0, set())
    e = Engine()
    e.submit(OfferCards(action_id="o", situations=sits, objects=objs))
    assert e.state.cards and len(e.state.cards) == 2


@pytest.mark.parametrize("which", range(6))
def test_director_invalid_fallback(which):
    bad = bad_proposals()[which]
    agent = DirectorAgent(Fixed("evil", bad), WM)
    sits, objs = agent.offer({}, 1, random.Random(1), set())
    assert agent.last_source == "template" and agent.last_error
    e = Engine()
    e.submit(OfferCards(action_id="o", situations=sits, objects=objs))  # engine accepts the fallback


def test_director_rejects_quiz_collision():
    from server.world.situation import build_observation, canonical_hash
    sits, objs = build_offer(good(), WM, 0, set())
    om = {o.id: o for o in objs}
    banned = {canonical_hash(build_observation(x, om)) for x in sits}
    with pytest.raises(ProposalError):
        build_offer(good(), WM, 0, banned)
    agent = DirectorAgent(Fixed("same", good()), WM)
    agent.offer({}, 1, random.Random(0), banned)
    assert agent.last_source == "template"  # fell back, and the template also avoided the banned scenes


def test_mock_client_drives_director_end_to_end():
    client = RouterClient([Boom(), MockClient({"director": mock_director_handler(WM)})])
    agent = DirectorAgent(client, WM)
    sits, objs = agent.offer({}, 1, random.Random(3), set())
    assert agent.last_source == "mock" and len(sits) == 2 and agent.last_error is None


def test_director_prefers_least_seen_kinds():
    prop = template_proposal({"cup": 9, "cloth": 9, "paper": 0, "ball": 1}, random.Random(0), set(), WM)
    assert {c.kind for c in prop.cards} == {"paper", "ball"}


def test_narrator_phrases_and_refs():
    text, hint = intro("sit_1", "bobo", "house", True, "cup")
    assert "bobo" in text and "cup" in hint
    assert intro("sit_1", "bobo", "house", False, "cup")[1] is None
    assert "not the bobo" in outcome("show", "paper", "bobo", False, "player")
    assert refs_ok("You bring the cup.", {"cup", "ball"})
    assert not refs_ok("You bring the cloth.", {"cup", "ball"})


def test_import_boundary_learning_never_imports_agents():
    root = Path(__file__).resolve().parents[1] / "server" / "learning"
    for f in root.glob("*.py"):
        for node in ast.walk(ast.parse(f.read_text())):
            names = []
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module or ""]
            assert not any(n.startswith("server.agents") or n.startswith("server.game") for n in names), f
