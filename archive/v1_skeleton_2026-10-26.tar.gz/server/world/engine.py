import re

from .catalog import KINDS, ObjectInst
from .events import (
    Cmd, Correct, EndDay, Event, EventType, OfferCards, PickCard, Praise, RecordLearned,
    RecordQuiz, RuleError, Show, Skip, Try,
)
from .situation import MAX_SLOTS, MIN_SLOTS, N_NAMES, Situation, answer_slots
from .state import Phase, WorldState, apply, current_answers, fold

N_CARDS = 2


class Engine:
    """The only component allowed to change world state. submit() validates, emits one event, applies it."""

    def __init__(self, per_day: int = 6, log: list[Event] | None = None):
        if log:
            self.log = list(log)
            self.state = fold(self.log)
        else:
            self.log = []
            self.state = WorldState()
            self._emit("init:day1", EventType.DAY_STARTED, {"per_day": per_day})

    # ---- internals ----
    def _emit(self, action_id: str, type_: EventType, payload: dict) -> Event:
        ev = Event(
            seq=len(self.log), action_id=action_id, day=self.state.day, type=type_, payload=payload
        )
        self.log.append(ev)
        self.state = apply(self.state, ev)
        return ev

    def _need_phase(self, phase: Phase) -> None:
        if self.state.phase != phase:
            raise RuleError("wrong_phase", f"need {phase}, in {self.state.phase}")

    def _need_untried_situation(self) -> Situation:
        self._need_phase(Phase.SITUATION)
        return self.state.current

    def _check_slot(self, slot: int) -> None:
        if not 0 <= slot < len(self.state.current.scene):
            raise RuleError("bad_slot", f"slot {slot}")

    # ---- the one entry point ----
    def submit(self, cmd: Cmd) -> list[Event]:
        if cmd.action_id in self.state.applied_action_ids:
            return []  # idempotent re-send
        s = self.state
        if isinstance(cmd, OfferCards):
            return [self._offer(cmd)]
        if isinstance(cmd, PickCard):
            self._need_phase(Phase.CARDS)
            if not s.cards:
                raise RuleError("no_cards")
            if not 0 <= cmd.index < len(s.cards):
                raise RuleError("bad_pick", str(cmd.index))
            return [self._emit(cmd.action_id, EventType.CARD_PICKED, {"index": cmd.index})]
        if isinstance(cmd, Show):
            cur = self._need_untried_situation()
            self._check_slot(cmd.slot)
            if cur.tried is not None:
                raise RuleError("already_tried")
            ok = cmd.slot in current_answers(s)
            return [self._emit(cmd.action_id, EventType.SHOWN, {"slot": cmd.slot, "was_right": ok})]
        if isinstance(cmd, Try):
            cur = self._need_untried_situation()
            self._check_slot(cmd.slot)
            if cur.tried is not None:
                raise RuleError("already_tried")
            ok = cmd.slot in current_answers(s)
            return [self._emit(cmd.action_id, EventType.CHILD_TRIED,
                               {"slot": cmd.slot, "was_right": ok, "probs": cmd.probs})]
        if isinstance(cmd, Praise):
            cur = self._need_untried_situation()
            if cur.tried is None:
                raise RuleError("no_try")
            if cur.tried not in current_answers(s):
                raise RuleError("tried_wrong", "cannot praise a wrong act")
            return [self._emit(cmd.action_id, EventType.PRAISED, {"slot": cur.tried})]
        if isinstance(cmd, Correct):
            cur = self._need_untried_situation()
            if cur.tried is None:
                raise RuleError("no_try")
            if cur.tried in current_answers(s):
                raise RuleError("tried_right", "nothing to correct")
            self._check_slot(cmd.slot)
            if cmd.slot == cur.tried:
                raise RuleError("same_slot")
            return [self._emit(cmd.action_id, EventType.CORRECTED, {
                "slot": cmd.slot, "rejected": cur.tried, "was_right": cmd.slot in current_answers(s)})]
        if isinstance(cmd, Skip):
            self._need_untried_situation()
            return [self._emit(cmd.action_id, EventType.SKIPPED, {})]
        if isinstance(cmd, RecordLearned):
            return [self._emit(cmd.action_id, EventType.LEARNED, {"report": cmd.report})]
        if isinstance(cmd, RecordQuiz):
            self._need_phase(Phase.EVENING)
            if s.quiz_taken:
                raise RuleError("quiz_done")
            return [self._emit(cmd.action_id, EventType.QUIZ_TAKEN, {"result": cmd.result})]
        if isinstance(cmd, EndDay):
            self._need_phase(Phase.EVENING)
            if not s.quiz_taken:
                raise RuleError("quiz_needed")
            return [self._emit(cmd.action_id, EventType.DAY_ENDED, {})]
        raise RuleError("unknown_command", type(cmd).__name__)

    def _offer(self, cmd: OfferCards) -> Event:
        s = self.state
        self._need_phase(Phase.CARDS)
        if s.cards is not None:
            raise RuleError("cards_already_offered")
        sits = [x if isinstance(x, Situation) else Situation(**x) for x in cmd.situations]
        objs = [x if isinstance(x, ObjectInst) else ObjectInst(**x) for x in cmd.objects]
        if len(sits) != N_CARDS:
            raise RuleError("bad_offer", f"need {N_CARDS} cards")
        by_id = {o.id: o for o in objs}
        if len(by_id) != len(objs) or any(i in s.objects for i in by_id):
            raise RuleError("bad_offer", "duplicate or reused object ids")
        words, kinds = dict(s.words), dict(s.word_kinds)
        out = []
        used: set[str] = set()
        for c in sits:
            if c.word_kind not in KINDS or not c.word:
                raise RuleError("bad_offer", "unknown kind or empty word")
            if kinds.get(c.word, c.word_kind) != c.word_kind:
                raise RuleError("bad_offer", f"word {c.word!r} already means another kind")
            if c.word not in kinds and c.word_kind in kinds.values():
                raise RuleError("bad_offer", f"kind {c.word_kind!r} already has a word")
            if not MIN_SLOTS <= len(c.scene) <= MAX_SLOTS or len(set(c.scene)) != len(c.scene):
                raise RuleError("bad_offer", "bad scene size")
            if any(i not in by_id or i in used for i in c.scene):
                raise RuleError("bad_offer", "scene object missing or shared between cards")
            used.update(c.scene)
            scene_objs = {i: by_id[i] for i in c.scene}
            if len(answer_slots(c, scene_objs)) != 1:
                raise RuleError("bad_offer", "need exactly one object of the requested kind")
            if c.word in words:
                if c.word_token and c.word_token != words[c.word]:
                    raise RuleError("bad_offer", f"word {c.word!r} already has token {words[c.word]}")
            else:
                tok = c.word_token or f"NAME_{len(words):02d}"
                m = re.fullmatch(r"NAME_(\d\d)", tok)
                if not m or int(m.group(1)) >= N_NAMES or tok in words.values():
                    raise RuleError("bad_offer", f"bad or reused name token {tok!r}")
                words[c.word] = tok
                kinds[c.word] = c.word_kind
            out.append(c.model_copy(update={"word_token": words[c.word], "tried": None, "resolution": None}))
        payload = {"situations": [c.model_dump() for c in out], "objects": [o.model_dump() for o in objs]}
        return self._emit(cmd.action_id, EventType.CARDS_OFFERED, payload)
