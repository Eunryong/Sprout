"""Situation model and the two views of it.

PlayerView shows the object kind label; Observation (the child's only input) never does.
The answer is computed by the engine from `word_kind` and is not part of Observation.
"""
import hashlib

from pydantic import BaseModel, ConfigDict

from .catalog import ObjectInst

MAX_SLOTS = 5
MIN_SLOTS = 3
N_NAMES = 32


class SlotView(BaseModel):
    model_config = ConfigDict(frozen=True)
    color: str
    shape: str
    size: str
    material: str


class Observation(BaseModel):
    request: str = "REQ_FIND"
    name_token: str
    slots: list[SlotView]


class SlotCard(BaseModel):
    index: int
    color: str
    shape: str
    size: str
    material: str
    kind_label: str


class Situation(BaseModel):
    id: str
    type: str = "find"
    word: str
    word_token: str = ""
    word_kind: str
    scene: list[str]
    location: str = "house"
    tried: int | None = None
    resolution: str | None = None


class PlayerView(BaseModel):
    narration: str
    word_hint: str | None
    cards: list[SlotCard]


def build_observation(sit: Situation, objects: dict[str, ObjectInst]) -> Observation:
    slots = []
    for oid in sit.scene:
        o = objects[oid]
        slots.append(SlotView(color=o.color, shape=o.shape, size=o.size, material=o.material))
    return Observation(name_token=sit.word_token, slots=slots)


def answer_slots(sit: Situation, objects: dict[str, ObjectInst]) -> list[int]:
    return [i for i, oid in enumerate(sit.scene) if objects[oid].kind == sit.word_kind]


def player_cards(sit: Situation, objects: dict[str, ObjectInst]) -> list[SlotCard]:
    out = []
    for i, oid in enumerate(sit.scene):
        o = objects[oid]
        out.append(
            SlotCard(index=i, color=o.color, shape=o.shape, size=o.size, material=o.material, kind_label=o.kind)
        )
    return out


def canonical_hash(obs: Observation) -> str:
    """Order-insensitive scene identity, used to keep quiz scenes out of training."""
    slots = sorted((s.color, s.shape, s.size, s.material) for s in obs.slots)
    raw = obs.name_token + "|" + ";".join(",".join(s) for s in slots)
    return hashlib.sha1(raw.encode()).hexdigest()[:16]
