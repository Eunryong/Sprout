"""Object catalog. `kind` is engine/player-only knowledge; the child sees attributes only."""
import random

from pydantic import BaseModel, ConfigDict

COLORS = ["red", "blue", "green", "yellow"]
SIZES = ["small", "big"]
SHAPES = ["cylinder", "flat", "sphere"]
MATERIALS = ["ceramic", "fabric", "paper", "rubber"]


class KindSpec(BaseModel):
    name: str
    shape: str
    material: str


# cloth and paper share a shape on purpose: one attribute alone cannot solve it.
KINDS: dict[str, KindSpec] = {
    k.name: k
    for k in [
        KindSpec(name="cup", shape="cylinder", material="ceramic"),
        KindSpec(name="cloth", shape="flat", material="fabric"),
        KindSpec(name="paper", shape="flat", material="paper"),
        KindSpec(name="ball", shape="sphere", material="rubber"),
    ]
}


class ObjectInst(BaseModel):
    model_config = ConfigDict(frozen=True)
    id: str
    kind: str
    color: str
    shape: str
    size: str
    material: str


def sample_object(
    rng: random.Random, obj_id: str, kind: str, color: str | None = None, size: str | None = None
) -> ObjectInst:
    spec = KINDS[kind]
    return ObjectInst(
        id=obj_id,
        kind=kind,
        color=color or rng.choice(COLORS),
        shape=spec.shape,
        size=size or rng.choice(SIZES),
        material=spec.material,
    )
