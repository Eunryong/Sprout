"""Deterministic scene template. Also the validated fallback for the Director later."""
import random

from .catalog import KINDS, ObjectInst, sample_object
from .situation import Situation, build_observation, canonical_hash

LOCATIONS = ["house", "yard"]


def make_situation(
    rng: random.Random,
    sit_id: str,
    start_obj: int,
    word: str,
    word_token: str,
    word_kind: str,
    forbidden: set[str] = frozenset(),
    n_slots: int | None = None,
    target_surface: tuple[str, str] | None = None,
) -> tuple[Situation, list[ObjectInst]]:
    """One target-kind object plus distinct-kind distractors. Rejects scenes whose canonical
    hash is in `forbidden` (the held-out quiz)."""
    others = [k for k in KINDS if k != word_kind]
    for _ in range(200):
        n = n_slots or rng.choice([3, 4])
        kinds = [word_kind] + rng.sample(others, n - 1)
        rng.shuffle(kinds)
        objs = []
        for j, k in enumerate(kinds):
            oid = f"obj_{start_obj + j:04d}"
            if k == word_kind and target_surface:
                objs.append(sample_object(rng, oid, k, color=target_surface[0], size=target_surface[1]))
            else:
                objs.append(sample_object(rng, oid, k))
        sit = Situation(
            id=sit_id, word=word, word_token=word_token, word_kind=word_kind,
            scene=[o.id for o in objs], location=rng.choice(LOCATIONS),
        )
        if canonical_hash(build_observation(sit, {o.id: o for o in objs})) not in forbidden:
            return sit, objs
    raise RuntimeError("could not generate a scene outside the forbidden set")
