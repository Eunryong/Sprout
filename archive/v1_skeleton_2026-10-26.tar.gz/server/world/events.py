from enum import StrEnum

from pydantic import BaseModel


class EventType(StrEnum):
    DAY_STARTED = "day_started"
    CARDS_OFFERED = "cards_offered"
    CARD_PICKED = "card_picked"
    SHOWN = "shown"
    CHILD_TRIED = "child_tried"
    PRAISED = "praised"
    CORRECTED = "corrected"
    SKIPPED = "skipped"
    LEARNED = "learned"
    QUIZ_TAKEN = "quiz_taken"
    DAY_ENDED = "day_ended"


class Event(BaseModel):
    seq: int
    action_id: str
    day: int
    type: EventType
    payload: dict = {}


# ---- commands (player/session -> engine). Plain data; the engine never calls a model or an LLM. ----
class Cmd(BaseModel):
    action_id: str


class OfferCards(Cmd):
    situations: list  # list[Situation]; validated by the engine
    objects: list  # list[ObjectInst]


class PickCard(Cmd):
    index: int


class Show(Cmd):
    slot: int


class Try(Cmd):
    slot: int  # chosen by the child model in the session
    probs: list[float] = []


class Praise(Cmd):
    pass


class Correct(Cmd):
    slot: int


class Skip(Cmd):
    pass


class RecordLearned(Cmd):
    report: dict


class RecordQuiz(Cmd):
    result: dict


class EndDay(Cmd):
    pass


class RuleError(Exception):
    def __init__(self, code: str, message: str = ""):
        super().__init__(f"{code}: {message}")
        self.code = code
