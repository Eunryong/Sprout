from enum import StrEnum

from pydantic import BaseModel

from .catalog import ObjectInst
from .events import Event, EventType
from .situation import Situation, answer_slots


class Phase(StrEnum):
    CARDS = "cards"
    SITUATION = "situation"
    EVENING = "evening"


class WorldState(BaseModel):
    day: int = 1
    phase: Phase = Phase.CARDS
    per_day: int = 6
    objects: dict[str, ObjectInst] = {}
    cards: list[Situation] | None = None
    current: Situation | None = None
    situations_done: int = 0
    quiz_taken: bool = False
    words: dict[str, str] = {}  # word -> NAME token (what the child could know)
    word_kinds: dict[str, str] = {}  # word -> kind (engine/player truth only)
    picked_words: set[str] = set()
    requests: dict[str, int] = {}  # times each kind was the picked request (Director balances coverage with this)
    current_first: bool = False  # first time this word is used in a picked situation (player hint)
    applied_action_ids: set[str] = set()
    last_seq: int = -1


def _finish(s: WorldState) -> None:
    s.situations_done += 1
    s.current = None
    s.phase = Phase.EVENING if s.situations_done >= s.per_day else Phase.CARDS


def apply(state: WorldState, ev: Event) -> WorldState:
    """Pure state transition. State changes only happen here."""
    s = state.model_copy(deep=True)
    s.last_seq = ev.seq
    s.applied_action_ids.add(ev.action_id)
    t, p = ev.type, ev.payload
    if t == EventType.DAY_STARTED:
        s.per_day = p.get("per_day", s.per_day)
    elif t == EventType.CARDS_OFFERED:
        for o in p["objects"]:
            s.objects[o["id"]] = ObjectInst(**o)
        s.cards = [Situation(**c) for c in p["situations"]]
        for c in s.cards:
            s.words.setdefault(c.word, c.word_token)
            s.word_kinds.setdefault(c.word, c.word_kind)
    elif t == EventType.CARD_PICKED:
        s.current = s.cards[p["index"]]
        s.current_first = s.current.word not in s.picked_words
        s.picked_words.add(s.current.word)
        s.requests[s.current.word_kind] = s.requests.get(s.current.word_kind, 0) + 1
        s.cards = None
        s.phase = Phase.SITUATION
    elif t == EventType.SHOWN:
        s.current.resolution = "show"
        _finish(s)
    elif t == EventType.CHILD_TRIED:
        s.current.tried = p["slot"]
    elif t in (EventType.PRAISED, EventType.CORRECTED):
        s.current.resolution = "try"
        _finish(s)
    elif t == EventType.SKIPPED:
        s.current.resolution = "skip"
        _finish(s)
    elif t == EventType.QUIZ_TAKEN:
        s.quiz_taken = True
    elif t == EventType.DAY_ENDED:
        s.day += 1
        s.situations_done = 0
        s.quiz_taken = False
        s.phase = Phase.CARDS
    # LEARNED: log only
    return s


def fold(events: list[Event]) -> WorldState:
    s = WorldState()
    for e in events:
        s = apply(s, e)
    return s


def current_answers(s: WorldState) -> list[int]:
    return answer_slots(s.current, s.objects)
