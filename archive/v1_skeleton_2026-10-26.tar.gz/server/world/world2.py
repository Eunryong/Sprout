"""World v2 prototype (WORLD.md): closed ontology + rules table + situation/option generator.

The rules table is the ONLY source of which option is good. The generator is the template fallback for the
future Director: it composes situations inside the ontology and never tells the child anything."""
import hashlib
import random

from pydantic import BaseModel, ConfigDict

from .catalog import COLORS, SIZES

TAGS = ["THIRSTY", "FLOOR_WET", "DARK", "COLD", "VISITOR", "REQUEST"]
VERBS = ["DRINK", "WIPE", "LIGHT", "COVER", "GIVE", "FETCH", "WAIT"]
SHAPES2 = ["cylinder", "flat", "tube", "long", "sphere"]
MATERIALS2 = ["ceramic", "fabric", "paper", "wool", "metal", "rubber"]
MAX_OPTS = 5
N_NAMES2 = 8

# kind -> (shape, material, allowed sizes). cloth / paper / blanket share a shape; flashlight / spoon share a material.
KINDS2: dict[str, tuple[str, str, list[str]]] = {
    "cup": ("cylinder", "ceramic", SIZES),
    "cloth": ("flat", "fabric", SIZES),
    "paper": ("flat", "paper", SIZES),
    "blanket": ("flat", "wool", ["big"]),
    "flashlight": ("tube", "metal", SIZES),
    "spoon": ("long", "metal", SIZES),
    "ball": ("sphere", "rubber", SIZES),
}
REQUEST_KINDS = ["cup", "cloth", "paper", "ball"]

# what a problem needs (used by the generator to put the right thing on the table)
NEEDS = {"THIRSTY": ("DRINK", "cup"), "FLOOR_WET": ("WIPE", "cloth"), "DARK": ("LIGHT", "flashlight"),
         "COLD": ("COVER", "blanket"), "VISITOR": ("GIVE", "ball")}

# the rules table: (verb, target kind) -> value. +2 solves, +1 partly, 0 nothing; anything missing is 0.
RULES: dict[str, dict[tuple[str, str], int]] = {
    "THIRSTY": {("DRINK", "cup"): 2},
    "FLOOR_WET": {("WIPE", "cloth"): 2, ("WIPE", "paper"): 1},
    "DARK": {("LIGHT", "flashlight"): 2},
    "COLD": {("COVER", "blanket"): 2, ("COVER", "cloth"): 1},
    "VISITOR": {("GIVE", "ball"): 2, ("GIVE", "cup"): 1},
}
WAIT_VALUE = {"THIRSTY": -1, "FLOOR_WET": -1, "DARK": 0, "COLD": -1, "VISITOR": -1, "REQUEST": 0}


class Obj2(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: str
    color: str
    shape: str
    size: str
    material: str


class OptionSpec(BaseModel):
    model_config = ConfigDict(frozen=True)
    verb: str
    target: int | None = None  # index into Situation2.objects


class Situation2(BaseModel):
    id: str
    tags: list[str]
    word: str | None = None
    word_token: str | None = None
    word_kind: str | None = None
    objects: list[Obj2]
    options: list[OptionSpec]


class SlotView2(BaseModel):
    model_config = ConfigDict(frozen=True)
    color: str
    shape: str
    size: str
    material: str


class OptionView(BaseModel):
    model_config = ConfigDict(frozen=True)
    verb: str
    target: SlotView2 | None = None


class Observation2(BaseModel):
    """The child's only input: tags, an optional word token, and the options with the target's ATTRIBUTES.
    No kind, no value, no narration."""
    tags: list[str]
    name_token: str | None = None
    options: list[OptionView]


def option_value(tags: list[str], word_kind: str | None, verb: str, obj: Obj2 | None) -> int:
    if verb == "WAIT":
        return min(WAIT_VALUE[t] for t in tags)
    best = 0
    for t in tags:
        if t == "REQUEST":
            v = 2 if verb == "FETCH" and obj is not None and obj.kind == word_kind else 0
        else:
            v = RULES[t].get((verb, obj.kind), 0) if obj is not None else 0
        best = max(best, v)
    return best


def values(sit: Situation2) -> list[int]:
    return [option_value(sit.tags, sit.word_kind, o.verb, sit.objects[o.target] if o.target is not None else None)
            for o in sit.options]


def optimal(sit: Situation2) -> list[int]:
    v = values(sit)
    return [i for i, x in enumerate(v) if x == max(v)]


def observation(sit: Situation2) -> Observation2:
    opts = []
    for o in sit.options:
        t = None
        if o.target is not None:
            ob = sit.objects[o.target]
            t = SlotView2(color=ob.color, shape=ob.shape, size=ob.size, material=ob.material)
        opts.append(OptionView(verb=o.verb, target=t))
    return Observation2(tags=sorted(sit.tags), name_token=sit.word_token if "REQUEST" in sit.tags else None, options=opts)


def obs_hash(obs: Observation2) -> str:
    """Order-insensitive scene identity (quiz isolation)."""
    def opt(o: OptionView):
        t = o.target
        return o.verb + ":" + (",".join([t.color, t.shape, t.size, t.material]) if t else "-")
    raw = ",".join(obs.tags) + "|" + str(obs.name_token) + "|" + ";".join(sorted(opt(o) for o in obs.options))
    return hashlib.sha1(raw.encode()).hexdigest()[:16]


def topic_of(sit: Situation2) -> str:
    return f"REQUEST:{sit.word_kind}" if sit.tags == ["REQUEST"] else "+".join(sorted(sit.tags))


def sample_obj(rng: random.Random, kind: str, avoid: set | None = None) -> Obj2:
    shape, material, sizes = KINDS2[kind]
    for _ in range(20):
        o = Obj2(kind=kind, color=rng.choice(COLORS), shape=shape, size=rng.choice(sizes), material=material)
        if not avoid or (o.color, o.size) not in avoid:
            return o
    return o


def _build(rng: random.Random, tags: list[str], word_kind: str | None):
    request = tags == ["REQUEST"]
    pairs = [("FETCH", word_kind)] if request else [NEEDS[t] for t in tags]
    good_kinds = [k for _, k in pairs]
    objs: list[Obj2] = []
    good: list[tuple[str, int]] = []
    for verb, kind in pairs:
        copies = rng.choice([1, 1, 2]) if len(pairs) == 1 and not request else 1
        seen: set = set()
        for _ in range(copies):
            o = sample_obj(rng, kind, seen)
            seen.add((o.color, o.size))
            objs.append(o)
            good.append((verb, len(objs) - 1))
    others = [k for k in KINDS2 if k not in good_kinds]
    n_wrong = rng.choice([2, 3]) if request else (1 if len(pairs) > 1 and rng.random() < 0.5 else 2)
    wrong_idx = []
    for k in rng.sample(others, n_wrong):
        objs.append(sample_obj(rng, k))
        wrong_idx.append(len(objs) - 1)
    opts = [OptionSpec(verb=v, target=i) for v, i in good]
    if request:
        opts += [OptionSpec(verb="FETCH", target=i) for i in wrong_idx]
        if rng.random() < 0.4:
            opts.append(OptionSpec(verb="WAIT"))
    else:
        opts.append(OptionSpec(verb=rng.choice([v for v, _ in pairs]), target=rng.choice(wrong_idx)))  # right verb, wrong thing
        used = {v for v, _ in pairs}
        opts.append(OptionSpec(verb=rng.choice([v for v in VERBS if v not in used and v != "WAIT"]),
                               target=rng.choice([i for _, i in good])))  # wrong verb, right thing
        if rng.random() < 0.5:
            opts.append(OptionSpec(verb="WAIT"))
        else:
            opts.append(OptionSpec(verb=rng.choice([v for v in VERBS if v != "WAIT"]), target=rng.randrange(len(objs))))
    uniq: list[OptionSpec] = []
    for o in opts:
        if o not in uniq:
            uniq.append(o)
    uniq = uniq[:MAX_OPTS]
    rng.shuffle(uniq)
    return objs, uniq


def make_situation2(rng: random.Random, tags: list[str], sid: str = "s", word: str | None = None,
                    word_token: str | None = None, word_kind: str | None = None,
                    forbidden: set[str] = frozenset()) -> Situation2:
    for _ in range(300):
        objs, opts = _build(rng, tags, word_kind)
        sit = Situation2(id=sid, tags=list(tags), word=word, word_token=word_token, word_kind=word_kind,
                         objects=objs, options=opts)
        v = values(sit)
        if max(v) >= 2 and min(v) < max(v) and obs_hash(observation(sit)) not in forbidden:
            return sit
    raise RuntimeError("could not generate a valid situation")
