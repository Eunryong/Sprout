import argparse
import random
import sys
import time
from pathlib import Path

from server.game.autoplay import play_day
from server.game.session import Session
from server.world.events import RuleError
from server.world.state import Phase

HELP = """commands:  pick N | show N | try | praise | correct N | skip | end | mind [DAY] | status | help | quit
  pick N     choose situation card N      show N     you bring item N (the child learns from your choice)
  try        let the child choose         praise / correct N   feedback after a try
  skip       let it pass (no learning)    end        evening quiz, next day (after all situations)
  mind [DAY] what the child reaches for, measured on the real model (DAY = compare with that day's snapshot)"""


def render(s: Session) -> None:
    v = s.view()
    print(f"\n=== Day {v.day} | situation {min(v.done + 1, v.per_day)}/{v.per_day} | {v.phase} ===")
    if v.phase == "cards":
        for p in v.previews:
            print(f"  [{p['index']}] {p['location']:5s} {p['items']} items   Grandma wants: \"{p['word']}\"")
    elif v.phase == "situation":
        print(v.narration)
        if v.hint:
            print(f"  ({v.hint})")
        for c in v.cards:
            print(f"   [{c.index}] {c.color:6s} {c.shape:9s} {c.size:6s} {c.material:8s} ({c.kind_label})")
        if v.tried is not None:
            print(f"  the child tried [{v.tried}] -> praise | correct N | skip")
    else:
        print("The day is over. Type `end` for the evening quiz.")


def show_result(r) -> None:
    if r.duplicate:
        print("(already applied)")
        return
    if r.narration:
        print(r.narration)
    if r.learn:
        l = r.learn
        print(f"  learned: {l.steps} steps | loss {l.loss_before:.2f} -> {l.loss_after:.2f} | {l.seconds:.2f}s")


def bar(x: float, w: int = 12) -> str:
    k = round(x * w)
    return "█" * k + "░" * (w - k)


def show_mind(s: Session, compare_day: int | None) -> None:
    m = s.mind(compare_day)
    if not m:
        print("The child has not met any word yet.")
        return
    for word, e in m.items():
        extra = f"  (before: {e['before']['accuracy']:.0%})" if "before" in e else ""
        print(f'"{word}" = {e["kind"]}   quiz accuracy {e["accuracy"]:.0%}{extra}')
        for attr, val, p in e["cues"]:
            was = ""
            if "before" in e:
                was = f"  was {e['before']['prefs'][attr][val]:.0%}"
            print(f"   reaches for {attr:8s} {val:9s} {bar(p)} {p:4.0%}{was}")
        print("   pull by attribute: " + "  ".join(f"{a} {v:.2f}" for a, v in e["pulls"].items()))


def run_command(s: Session, line: str) -> bool:
    parts = line.split()
    if not parts:
        return True
    cmd, arg = parts[0], (int(parts[1]) if len(parts) > 1 and parts[1].lstrip("-").isdigit() else None)
    need = {"pick", "show", "correct"}
    if cmd in need and arg is None:
        print(f"usage: {cmd} N")
        return True
    if cmd in ("quit", "q", "exit"):
        return False
    if cmd == "help":
        print(HELP)
    elif cmd == "status":
        print(f"events={len(s.engine.log)} examples={len(s.buffer)} save={s.save.root}")
        for w in s.warnings:
            print("  warning:", w)
    elif cmd == "mind":
        show_mind(s, arg)
    elif cmd == "pick":
        s.pick_card(arg)
    elif cmd == "show":
        show_result(s.show(arg))
    elif cmd == "try":
        show_result(s.try_child())
    elif cmd == "praise":
        show_result(s.praise())
    elif cmd == "correct":
        show_result(s.correct(arg))
    elif cmd == "skip":
        show_result(s.skip())
    elif cmd == "end":
        r = s.end_day()
        print(f"Evening quiz ({r['n']} questions): child {r['p_correct']:.2f}  | random {r['random']:.2f} | "
              f"untrained {r['untrained_p']:.2f}   (full held-out pool: {r['pool_p_correct']:.2f}, n={r['pool_n']})")
    else:
        print("unknown command; type help")
    return True


def repl(s: Session) -> None:
    print(HELP)
    for w in s.warnings:
        print("warning:", w)
    while True:
        if s.state.phase == Phase.CARDS and s.state.cards is None:
            s.draw_cards()
        render(s)
        try:
            line = input("> ")
        except EOFError:
            print("\n(saved)")
            return
        try:
            if not run_command(s, line):
                print("(saved)")
                return
        except RuleError as e:
            print(f"! {e.code}: {e}")


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="server.cli")
    sub = ap.add_subparsers(dest="mode", required=True)
    n = sub.add_parser("new"); n.add_argument("--seed", type=int, default=0); n.add_argument("--save", default="")
    l = sub.add_parser("load"); l.add_argument("save")
    a = sub.add_parser("autoplay"); a.add_argument("--seed", type=int, default=0); a.add_argument("--days", type=int, default=3)
    a.add_argument("--save", default=""); a.add_argument("--p-show", type=float, default=0.5)
    args = ap.parse_args(argv)
    if args.mode == "load":
        repl(Session.load(args.save))
        return
    path = args.save or f"saves/{time.strftime('%Y%m%d-%H%M%S')}-seed{args.seed}"
    s = Session.new(path, seed=args.seed)
    print(f"new save: {path}")
    if args.mode == "new":
        repl(s)
        return
    rng = random.Random(args.seed + 1)
    for _ in range(args.days):
        r = play_day(s, rng, args.p_show)
        print(f"day {r['day']}: quiz {r['p_correct']:.2f} (random {r['random']:.2f}, untrained {r['untrained_p']:.2f}) "
              f"pool {r['pool_p_correct']:.2f}  examples={len(s.buffer)}")


if __name__ == "__main__":
    main()
