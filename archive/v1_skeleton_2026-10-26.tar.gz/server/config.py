from dataclasses import dataclass, field
from pathlib import Path

import yaml

from server.learning.learner import OnlineCfg
from server.learning.model import ModelCfg

CONFIG_DIR = Path(__file__).resolve().parents[1] / "config"


@dataclass
class GameCfg:
    per_day: int = 6
    quiz_per_kind: int = 20
    quiz_per_day: int = 8
    words: list[str] = field(default_factory=lambda: ["bobo", "mimi", "tata", "lulu"])


def _read(name: str) -> dict:
    p = CONFIG_DIR / name
    return yaml.safe_load(p.read_text()) or {} if p.exists() else {}


def load_configs() -> tuple[GameCfg, ModelCfg, OnlineCfg]:
    g, m = _read("game.yaml"), _read("model.yaml")
    return GameCfg(**g), ModelCfg(**m.get("model", {})), OnlineCfg(**m.get("online", {}))
