import random

from pydantic import BaseModel

from server.world.scenegen import make_situation
from server.world.situation import Observation, answer_slots, build_observation, canonical_hash

from .policy import slot_probs


class QuizItem(BaseModel):
    obs: Observation
    answers: list[int]
    kind: str
    color: str  # surface of the target object (analysis only)
    size: str
    hash: str


def make_quiz(rng: random.Random, kind_tokens: dict[str, tuple[str, str]], n_per_kind: int) -> list[QuizItem]:
    """kind -> (word, token). Fresh individuals and placements; deduplicated by canonical hash."""
    items, seen = [], set()
    for kind, (word, token) in kind_tokens.items():
        got = 0
        while got < n_per_kind:
            sit, objs = make_situation(rng, "quiz", 0, word, token, kind)
            om = {o.id: o for o in objs}
            obs = build_observation(sit, om)
            h = canonical_hash(obs)
            if h in seen:
                continue
            seen.add(h)
            ans = answer_slots(sit, om)
            t = om[sit.scene[ans[0]]]
            items.append(QuizItem(obs=obs, answers=ans, kind=kind, color=t.color, size=t.size, hash=h))
            got += 1
    return items


def score(model, items: list[QuizItem]) -> dict:
    """p_correct = mean probability mass the model puts on the right slot (deterministic, less noisy than
    a single sample); greedy = argmax accuracy; random = chance level for these scenes."""
    if not items:
        return {"p_correct": float("nan"), "greedy": float("nan"), "random": float("nan"), "n": 0}
    pc = gr = rd = 0.0
    for it in items:
        p = slot_probs(model, it.obs)
        pc += sum(p[a] for a in it.answers)
        gr += max(range(len(p)), key=p.__getitem__) in it.answers
        rd += len(it.answers) / len(it.obs.slots)
    n = len(items)
    return {"p_correct": pc / n, "greedy": gr / n, "random": rd / n, "n": n}


def save_quiz(items: list[QuizItem], path) -> None:
    from pathlib import Path
    Path(path).write_text("".join(it.model_dump_json() + "\n" for it in items))


def load_quiz(path) -> list[QuizItem]:
    from pathlib import Path
    return [QuizItem.model_validate_json(line) for line in Path(path).read_text().splitlines() if line]


def pick_daily(items: list[QuizItem], known_tokens: set[str], rng: random.Random, n: int) -> list[QuizItem]:
    """Evening quiz: only words the child has actually met, a fresh deterministic sample each evening."""
    pool = [q for q in items if q.obs.name_token in known_tokens]
    return rng.sample(pool, min(n, len(pool)))


def evaluate(model, model0, items: list[QuizItem]) -> dict:
    """Score against the two baselines. `model0` is the immutable ckpt_000 (learning-disabled control)."""
    s, b = score(model, items), score(model0, items)
    return {"n": s["n"], "p_correct": s["p_correct"], "greedy": s["greedy"], "random": s["random"],
            "untrained_p": b["p_correct"], "untrained_greedy": b["greedy"]}
