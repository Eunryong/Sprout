import hashlib
import random

import torch
from pydantic import BaseModel

from server.world.catalog import COLORS, KINDS, SIZES
from server.world.situation import MAX_SLOTS, Observation, SlotView

from .tokenizer import encode
from .vocab import PAD, SLOT_IDS


class Example(BaseModel):
    id: str
    day: int
    source: str  # show | praise | correct
    obs: Observation
    target_slot: int
    weight: float = 1.0
    rejected_slot: int | None = None
    was_right: bool = True  # analysis only, never a model input


def shuffle_slots(ex: Example, rng: random.Random) -> Example:
    """Only augmentation allowed: slot order. Surface attributes are never changed (DESIGN 4.5)."""
    perm = list(range(len(ex.obs.slots)))
    rng.shuffle(perm)
    slots = [ex.obs.slots[i] for i in perm]
    return ex.model_copy(update={
        "obs": ex.obs.model_copy(update={"slots": slots}),
        "target_slot": perm.index(ex.target_slot),
        "rejected_slot": None if ex.rejected_slot is None else perm.index(ex.rejected_slot),
    })


_KIND_PAIRS = sorted({(k.shape, k.material) for k in KINDS.values()})


def redraw_distractors(ex: Example, rng: random.Random) -> Example:
    """Allowed augmentation (DESIGN 4.5): keep the taught slot exactly as the player showed it and re-draw
    every OTHER slot as a different kind with fresh color/size. The target's own attributes (the thing the
    player teaches) are never touched, so this adds no target diversity the player did not provide."""
    t, n = ex.target_slot, len(ex.obs.slots)
    tgt = ex.obs.slots[t]
    others = [p for p in _KIND_PAIRS if p != (tgt.shape, tgt.material)]
    picks = rng.sample(others, n - 1) if n - 1 <= len(others) else [rng.choice(others) for _ in range(n - 1)]
    slots, j = list(ex.obs.slots), 0
    for i in range(n):
        if i == t:
            continue
        shape, material = picks[j]
        j += 1
        slots[i] = SlotView(color=rng.choice(COLORS), shape=shape, size=rng.choice(SIZES), material=material)
    return ex.model_copy(update={"obs": ex.obs.model_copy(update={"slots": slots}), "rejected_slot": None})


def augment(ex: Example, rng: random.Random, p_redraw: float = 0.0) -> Example:
    if p_redraw > 0 and rng.random() < p_redraw:
        ex = redraw_distractors(ex, rng)
    return shuffle_slots(ex, rng)


def collate(exs: list[Example]):
    seqs = [encode(e.obs) for e in exs]
    T = max(len(s) for s in seqs)
    ids = torch.full((len(exs), T), PAD, dtype=torch.long)
    for i, s in enumerate(seqs):
        ids[i, : len(s)] = torch.tensor(s)
    lengths = torch.tensor([len(s) for s in seqs])
    n_slots = torch.tensor([len(e.obs.slots) for e in exs])
    target = torch.tensor([e.target_slot for e in exs])
    weight = torch.tensor([e.weight for e in exs], dtype=torch.float)
    return ids, lengths, n_slots, target, weight


def slot_logits(model, ids, lengths, n_slots):
    """Logits over SLOT_0..SLOT_{n-1} at the last real position; slots that do not exist are masked.
    Every existing slot stays allowed (grammar mask never reveals the answer)."""
    logits = model(ids)
    last = logits[torch.arange(ids.shape[0]), lengths - 1]
    sl = last[:, SLOT_IDS]
    valid = torch.arange(MAX_SLOTS).unsqueeze(0) < n_slots.unsqueeze(1)
    return sl.masked_fill(~valid, float("-inf"))


def data_hash(exs: list[Example]) -> str:
    raw = "|".join(f"{e.id}:{e.target_slot}:{e.weight}" for e in exs)
    return hashlib.sha1(raw.encode()).hexdigest()[:12]
