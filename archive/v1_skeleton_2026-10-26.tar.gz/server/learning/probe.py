"""Contrast probe for the 'inside the child's head' panel (DESIGN 4.6).

For one word, build small scenes with two slots that differ in exactly ONE attribute (the rest identical) plus a
filler of another kind, and ask the real model which of the pair it reaches for. Averaged over random bases and
both slot orders, pref[attr][value] is the chance the child prefers that value over a competing value of the same
attribute: 0.5 = indifferent, near 1.0 = reaches for it. These are measurements of the model, not LLM prose.

Note: contrasts on shape/material can create objects that do not exist in the catalog (e.g. a flat ceramic thing).
That is intentional for a probe; it isolates one attribute, at the cost of being a little off-distribution."""
import random

from server.world.catalog import COLORS, KINDS, MATERIALS, SHAPES, SIZES
from server.world.situation import Observation, SlotView

from .policy import slot_probs

ATTRS: dict[str, list[str]] = {"color": COLORS, "shape": SHAPES, "size": SIZES, "material": MATERIALS}


def _slot(kind: str, rng: random.Random) -> dict:
    spec = KINDS[kind]
    return {"color": rng.choice(COLORS), "shape": spec.shape, "size": rng.choice(SIZES), "material": spec.material}


def probe_word(model, name_token: str, rng: random.Random | None = None, n: int = 30) -> dict[str, dict[str, float]]:
    rng = rng or random.Random(0)
    kinds = list(KINDS)
    sums = {a: {v: 0.0 for v in vs} for a, vs in ATTRS.items()}
    cnt = {a: {v: 0 for v in vs} for a, vs in ATTRS.items()}
    for attr, values in ATTRS.items():
        for _ in range(n):
            base_kind = rng.choice(kinds)
            base = _slot(base_kind, rng)
            filler = _slot(rng.choice([k for k in kinds if k != base_kind]), rng)
            v1, v2 = rng.sample(values, 2)
            a, b = dict(base, **{attr: v1}), dict(base, **{attr: v2})
            slots = [("A", a), ("B", b), ("F", filler)]
            rng.shuffle(slots)
            obs = Observation(name_token=name_token, slots=[SlotView(**s) for _, s in slots])
            p = slot_probs(model, obs)
            pa = p[[t for t, _ in slots].index("A")]
            pb = p[[t for t, _ in slots].index("B")]
            pref = pa / (pa + pb) if pa + pb > 0 else 0.5
            sums[attr][v1] += pref
            cnt[attr][v1] += 1
            sums[attr][v2] += 1 - pref
            cnt[attr][v2] += 1
    return {a: {v: (sums[a][v] / cnt[a][v] if cnt[a][v] else 0.5) for v in vs} for a, vs in ATTRS.items()}


def pulls(prefs: dict[str, dict[str, float]]) -> dict[str, float]:
    """How strongly each attribute steers the choice: largest deviation from indifference (0..0.5)."""
    return {a: max(abs(p - 0.5) for p in vs.values()) for a, vs in prefs.items()}


def top_cues(prefs: dict[str, dict[str, float]], k: int = 3) -> list[tuple[str, str, float]]:
    """The values the child reaches for most (pref > 0.5), strongest first."""
    cues = [(a, v, p) for a, vs in prefs.items() for v, p in vs.items() if p > 0.5]
    return sorted(cues, key=lambda c: -c[2])[:k]
