from server.world.situation import Observation

from .vocab import TOK


def encode(obs: Observation) -> list[int]:
    """[BOS] REQ NAME [SEP] (SLOT c s z m [SEP])* ACT_PICK  -- the next token predicts the slot."""
    ids = [TOK["[BOS]"], TOK[obs.request], TOK[obs.name_token], TOK["[SEP]"]]
    for i, s in enumerate(obs.slots):
        ids += [
            TOK[f"SLOT_{i}"], TOK[f"COLOR_{s.color}"], TOK[f"SHAPE_{s.shape}"],
            TOK[f"SIZE_{s.size}"], TOK[f"MAT_{s.material}"], TOK["[SEP]"],
        ]
    ids.append(TOK["ACT_PICK"])
    return ids
