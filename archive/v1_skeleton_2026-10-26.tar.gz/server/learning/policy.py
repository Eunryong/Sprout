import random

import torch
from pydantic import BaseModel

from server.world.situation import Observation

from .dataset import Example, collate, slot_logits


class ChildAct(BaseModel):
    slot: int
    probs: list[float]


@torch.no_grad()
def slot_probs(model, obs: Observation) -> list[float]:
    model.eval()
    dummy = Example(id="q", day=0, source="show", obs=obs, target_slot=0)
    ids, lengths, n_slots, _, _ = collate([dummy])
    p = torch.softmax(slot_logits(model, ids, lengths, n_slots), dim=-1)[0]
    return p[: len(obs.slots)].tolist()


def act(model, obs: Observation, rng: random.Random | None = None, greedy: bool = False) -> ChildAct:
    probs = slot_probs(model, obs)
    if greedy or rng is None:
        slot = max(range(len(probs)), key=probs.__getitem__)
    else:
        slot = rng.choices(range(len(probs)), weights=probs)[0]
    return ChildAct(slot=slot, probs=probs)
