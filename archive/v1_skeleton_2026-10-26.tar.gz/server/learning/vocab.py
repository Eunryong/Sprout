from server.world.catalog import COLORS, MATERIALS, SHAPES, SIZES
from server.world.situation import MAX_SLOTS, N_NAMES

SPECIAL = ["[PAD]", "[BOS]", "[SEP]", "[EOS]"]

VOCAB: list[str] = (
    SPECIAL
    + ["REQ_FIND", "ACT_PICK"]
    + [f"SLOT_{i}" for i in range(MAX_SLOTS)]
    + [f"COLOR_{c}" for c in COLORS]
    + [f"SHAPE_{s}" for s in SHAPES]
    + [f"SIZE_{s}" for s in SIZES]
    + [f"MAT_{m}" for m in MATERIALS]
    + [f"NAME_{i:02d}" for i in range(N_NAMES)]
)
TOK: dict[str, int] = {t: i for i, t in enumerate(VOCAB)}
PAD = TOK["[PAD]"]
SLOT_IDS = [TOK[f"SLOT_{i}"] for i in range(MAX_SLOTS)]
MAX_LEN = 4 + MAX_SLOTS * 6 + 1
