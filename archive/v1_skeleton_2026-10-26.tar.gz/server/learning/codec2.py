"""World v2 codec: tokens, encoding, loss, augmentation, quiz scoring. Isolated from v1 on purpose (P1 prototype)."""
import random

import torch
import torch.nn.functional as F
from pydantic import BaseModel

from server.world.catalog import COLORS, SIZES
from server.world.world2 import (
    KINDS2, MATERIALS2, MAX_OPTS, N_NAMES2, SHAPES2, TAGS, VERBS, Observation2, OptionView, SlotView2,
    Situation2, obs_hash, observation, optimal, topic_of, values,
)

VOCAB2: list[str] = (
    ["[PAD]", "[BOS]", "[SEP]", "[EOS]", "ACT_PICK"]
    + [f"TAG_{t}" for t in TAGS] + [f"VERB_{v}" for v in VERBS] + [f"OPT_{i}" for i in range(MAX_OPTS)]
    + [f"COLOR_{c}" for c in COLORS] + [f"SHAPE_{s}" for s in SHAPES2] + [f"SIZE_{s}" for s in SIZES]
    + [f"MAT_{m}" for m in MATERIALS2] + [f"NAME_{i:02d}" for i in range(N_NAMES2)]
)
TOK2 = {t: i for i, t in enumerate(VOCAB2)}
PAD = TOK2["[PAD]"]
OPT_IDS = [TOK2[f"OPT_{i}"] for i in range(MAX_OPTS)]
MAX_LEN2 = 1 + 2 + 1 + 1 + MAX_OPTS * 7 + 1  # BOS tags name SEP options ACT_PICK


def encode2(obs: Observation2) -> list[int]:
    ids = [TOK2["[BOS]"]] + [TOK2[f"TAG_{t}"] for t in obs.tags]
    if obs.name_token:
        ids.append(TOK2[obs.name_token])
    ids.append(TOK2["[SEP]"])
    for i, o in enumerate(obs.options):
        ids += [TOK2[f"OPT_{i}"], TOK2[f"VERB_{o.verb}"]]
        if o.target is not None:
            t = o.target
            ids += [TOK2[f"COLOR_{t.color}"], TOK2[f"SHAPE_{t.shape}"], TOK2[f"SIZE_{t.size}"], TOK2[f"MAT_{t.material}"]]
        ids.append(TOK2["[SEP]"])
    ids.append(TOK2["ACT_PICK"])
    return ids


class Example2(BaseModel):
    id: str
    day: int
    source: str  # show | praise | correct
    obs: Observation2
    target_slot: int  # option index (name kept so Learner/data_hash are shared with v1)
    weight: float = 1.0
    rejected_slot: int | None = None
    was_right: bool = True  # analysis only


def collate2(exs: list[Example2]):
    seqs = [encode2(e.obs) for e in exs]
    T = max(len(s) for s in seqs)
    ids = torch.full((len(exs), T), PAD, dtype=torch.long)
    for i, s in enumerate(seqs):
        ids[i, : len(s)] = torch.tensor(s)
    return (ids, torch.tensor([len(s) for s in seqs]), torch.tensor([len(e.obs.options) for e in exs]),
            torch.tensor([e.target_slot for e in exs]), torch.tensor([e.weight for e in exs], dtype=torch.float))


def option_logits(model, ids, lengths, n_opts):
    last = model(ids)[torch.arange(ids.shape[0]), lengths - 1][:, OPT_IDS]
    valid = torch.arange(MAX_OPTS).unsqueeze(0) < n_opts.unsqueeze(1)
    return last.masked_fill(~valid, float("-inf"))  # every existing option stays allowed


def weighted_ce2(model, exs: list[Example2]) -> torch.Tensor:
    ids, lengths, n, target, weight = collate2(exs)
    ce = F.cross_entropy(option_logits(model, ids, lengths, n), target, reduction="none")
    return (ce * weight).sum() / weight.sum()


@torch.no_grad()
def option_probs(model, obs: Observation2) -> list[float]:
    model.eval()
    ids, lengths, n, _, _ = collate2([Example2(id="q", day=0, source="show", obs=obs, target_slot=0)])
    return torch.softmax(option_logits(model, ids, lengths, n), dim=-1)[0][: len(obs.options)].tolist()


# ---- augmentation (DESIGN 4.5 spirit): shuffle option order; optionally re-draw the OTHER options ----
_PAIRS = sorted({(s, m) for s, m, _ in KINDS2.values()})


def _same_option(a: OptionView, b: OptionView) -> bool:
    return a == b


def redraw_options(ex: Example2, rng: random.Random) -> Example2:
    """Keep the option the player chose exactly as chosen; replace every other option by a random one that
    differs from it in the verb or in the kind of thing it targets. Uses no rule knowledge (nothing about which
    options are good), only what the taught example already contains."""
    n, t = len(ex.obs.options), ex.target_slot
    chosen = ex.obs.options[t]
    out = list(ex.obs.options)
    for i in range(n):
        if i == t:
            continue
        for _ in range(50):
            verb = rng.choice(VERBS)
            if verb == "WAIT":
                cand = OptionView(verb="WAIT", target=None)
            else:
                shape, mat = rng.choice(_PAIRS)
                cand = OptionView(verb=verb, target=SlotView2(color=rng.choice(COLORS), shape=shape, size=rng.choice(SIZES), material=mat))
            same_kind = (chosen.target is not None and cand.target is not None
                         and (chosen.target.shape, chosen.target.material) == (cand.target.shape, cand.target.material))
            if cand.verb == chosen.verb and (same_kind or (chosen.target is None and cand.target is None)):
                continue  # would look like a duplicate of what the player chose
            if cand in out:
                continue
            out[i] = cand
            break
    return ex.model_copy(update={"obs": ex.obs.model_copy(update={"options": out}), "rejected_slot": None})


def shuffle_options(ex: Example2, rng: random.Random) -> Example2:
    perm = list(range(len(ex.obs.options)))
    rng.shuffle(perm)
    opts = [ex.obs.options[i] for i in perm]
    return ex.model_copy(update={
        "obs": ex.obs.model_copy(update={"options": opts}), "target_slot": perm.index(ex.target_slot),
        "rejected_slot": None if ex.rejected_slot is None else perm.index(ex.rejected_slot)})


def augment2(ex: Example2, rng: random.Random, p_redraw: float = 0.0) -> Example2:
    if p_redraw > 0 and rng.random() < p_redraw:
        ex = redraw_options(ex, rng)
    return shuffle_options(ex, rng)


# ---- quiz ----
class QuizItem2(BaseModel):
    obs: Observation2
    values: list[int]
    topic: str
    hash: str


def make_quiz2(rng: random.Random, topics: list[tuple[list[str], str | None, str | None, str | None]], n_per_topic: int):
    """topics: (tags, word, token, word_kind). Fresh situations, deduplicated by hash."""
    from server.world.world2 import make_situation2
    items, seen = [], set()
    for tags, word, token, kind in topics:
        got = 0
        while got < n_per_topic:
            sit = make_situation2(rng, tags, "quiz", word, token, kind)
            obs = observation(sit)
            h = obs_hash(obs)
            if h in seen:
                continue
            seen.add(h)
            items.append(QuizItem2(obs=obs, values=values(sit), topic=topic_of(sit), hash=h))
            got += 1
    return items


def score2(model, items: list[QuizItem2]) -> dict:
    """optimal = share of greedy picks that are a best option; p_opt = probability mass on best options;
    value = mean value of the greedy pick; random = chance of a best option under a uniform pick."""
    if not items:
        return {k: float("nan") for k in ("optimal", "p_opt", "value", "random")} | {"n": 0}
    opt = p = val = rnd = 0.0
    for q in items:
        pr = option_probs(model, q.obs)
        best = max(q.values)
        good = [i for i, v in enumerate(q.values) if v == best]
        g = max(range(len(pr)), key=pr.__getitem__)
        opt += g in good
        p += sum(pr[i] for i in good)
        val += q.values[g]
        rnd += len(good) / len(pr)
    n = len(items)
    return {"optimal": opt / n, "p_opt": p / n, "value": val / n, "random": rnd / n, "n": n}
