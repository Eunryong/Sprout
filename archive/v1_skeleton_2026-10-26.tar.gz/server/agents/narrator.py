"""Narrator. Prototype uses fixed phrases only. Anything an LLM narrator writes later must pass refs_ok()
or be replaced by the fixed phrase. It never decides facts: the caller passes facts already settled by the engine."""
from server.world.catalog import KINDS

INTROS = [
    'Grandma ({loc}): "Could you bring me the {word}?"',
    'Grandma ({loc}): "{word}, please!"',
    'Grandma ({loc}) points at the table: "I\'d like the {word}."',
]


def intro(sit_id: str, word: str, location: str, first_use: bool, kind: str) -> tuple[str, str | None]:
    text = INTROS[sum(map(ord, sit_id)) % len(INTROS)].format(word=word, loc=location)
    hint = f'"{word}" means {kind} (Grandma\'s word; the child cannot see this).' if first_use else None
    return text, hint


def outcome(mode: str, chosen_kind: str, word: str, was_right: bool, who: str) -> str:
    verb = "brings" if who == "child" else "bring"
    subj = "The child" if who == "child" else "You"
    if was_right:
        return f"{subj} {verb} the {chosen_kind}. Grandma smiles: that is the {word}!"
    return f"{subj} {verb} the {chosen_kind}. Grandma tilts her head: that is not the {word}."


def refs_ok(text: str, allowed_kinds: set[str]) -> bool:
    """Reject text that names a kind that is not on the table (cheap check; not a full hallucination guard)."""
    words = {w.strip('.,!?:;"()').lower() for w in text.split()}
    return all(k in allowed_kinds for k in KINDS if k in words)
