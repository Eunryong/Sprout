from pydantic import BaseModel


class ObjSpec(BaseModel):
    kind: str
    color: str
    size: str


class CardProposal(BaseModel):
    kind: str  # the kind the request is about (word comes from the save, not from the model)
    location: str = "house"
    objects: list[ObjSpec]


class DirectorProposal(BaseModel):
    cards: list[CardProposal]


class NarrationOut(BaseModel):
    text: str
