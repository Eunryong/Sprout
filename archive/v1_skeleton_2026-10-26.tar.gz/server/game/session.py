"""Game loop. CLI and (later) FastAPI only call this class."""
import random
import uuid
from dataclasses import asdict, dataclass, field

from pydantic import BaseModel

from server.agents import narrator
from server.agents.client import MockClient, RouterClient
from server.agents.director import DirectorAgent, mock_director_handler
from server.config import GameCfg, load_configs
from server.learning import checkpoints
from server.learning.dataset import Example
from server.learning.evaluator import evaluate, load_quiz, make_quiz, pick_daily, save_quiz, score
from server.learning.learner import LearnReport, Learner, OnlineCfg
from server.learning.model import ModelCfg, build_model
from server.learning.policy import act
from server.learning.probe import probe_word, pulls, top_cues
from server.world.engine import Engine
from server.world.events import (
    Correct, EndDay, OfferCards, PickCard, Praise, RecordLearned, RecordQuiz, RuleError, Show, Skip, Try,
)
from server.world.catalog import KINDS
from server.world.situation import SlotCard, answer_slots, build_observation, player_cards
from server.world.state import Phase

from .saves import SaveDir

DEFAULT = object()


class ActionResult(BaseModel):
    duplicate: bool = False
    narration: str = ""
    slot: int | None = None
    was_right: bool | None = None
    probs: list[float] = []
    learn: LearnReport | None = None


class SceneView(BaseModel):
    day: int
    done: int
    per_day: int
    phase: str
    narration: str = ""
    hint: str | None = None
    cards: list[SlotCard] = []
    previews: list[dict] = []
    tried: int | None = None


def default_client(word_map: dict):
    return RouterClient([MockClient({"director": mock_director_handler(word_map)})])


class Session:
    def __init__(self, save: SaveDir, meta: dict, engine: Engine, model, model0, learner: Learner,
                 buffer: list[Example], quiz: list, client):
        self.save, self.meta, self.engine = save, meta, engine
        self.model, self.model0, self.learner = model, model0, learner
        self.buffer, self.quiz = buffer, quiz
        self.seed = meta["seed"]
        self.game = GameCfg(**meta["game"])
        self.word_map = {k: tuple(v) for k, v in meta["word_map"].items()}
        self.forbidden = {q.hash for q in quiz}
        self.director = DirectorAgent(default_client(self.word_map) if client is DEFAULT else client, self.word_map)
        self.warnings: list[str] = []

    # ---- construction ----
    @classmethod
    def new(cls, save_dir, seed: int = 0, game: GameCfg | None = None, mcfg: ModelCfg | None = None,
            ocfg: OnlineCfg | None = None, client=DEFAULT) -> "Session":
        g0, m0, o0 = load_configs()
        game, mcfg, ocfg = game or g0, mcfg or m0, ocfg or o0
        save = SaveDir(save_dir)
        save.create()
        rng = random.Random(seed)
        words = list(game.words)
        rng.shuffle(words)
        word_map = {k: (words[i], f"NAME_{i:02d}") for i, k in enumerate(KINDS)}
        mcfg.seed = seed
        model = build_model(mcfg)
        checkpoints.save(model, save.ckpt0, meta={"role": "initial"}, overwrite=False)
        quiz = make_quiz(random.Random(seed + 10_000), word_map, game.quiz_per_kind)
        save_quiz(quiz, save.quiz)
        meta = {"seed": seed, "game": asdict(game), "model": mcfg.to_dict(), "online": asdict(ocfg),
                "word_map": {k: list(v) for k, v in word_map.items()}}
        engine = Engine(per_day=game.per_day)
        for ev in engine.log:
            save.append_event(ev)
        save.write_meta(meta)
        model0 = checkpoints.load(save.ckpt0)[0]
        return cls(save, meta, engine, model, model0, Learner(model, ocfg), [], quiz, client)

    @classmethod
    def load(cls, save_dir, client=DEFAULT) -> "Session":
        save = SaveDir(save_dir)
        if not save.exists():
            raise FileNotFoundError(f"no save at {save_dir}")
        meta = save.read_meta()
        ocfg = OnlineCfg(**meta["online"])
        engine = Engine(log=save.read_events())
        buffer = save.read_examples()
        src = save.latest if save.latest.exists() else save.ckpt0
        model, ck_meta = checkpoints.load(src)
        learner = Learner(model, ocfg)
        learner.n_calls = len(buffer)
        checkpoints.load_optimizer_state(src, learner.opt)
        s = cls(save, meta, engine, model, checkpoints.load(save.ckpt0)[0], learner, buffer,
                load_quiz(save.quiz), client)
        n_events = sum(e.type.value == "learned" for e in engine.log)
        if not (len(buffer) == n_events == ck_meta.get("n_learned", 0)):
            s.warnings.append(f"learning log mismatch: examples={len(buffer)} learned_events={n_events} "
                              f"checkpoint={ck_meta.get('n_learned', 0)} (interrupted save?)")
        return s

    # ---- helpers ----
    @property
    def state(self):
        return self.engine.state

    def _rng(self, salt: str) -> random.Random:
        return random.Random(f"{self.seed}:{len(self.engine.log)}:{salt}")  # same history -> same randomness

    def _submit(self, cmd):
        evs = self.engine.submit(cmd)  # raises RuleError before anything is persisted
        for ev in evs:
            self.save.append_event(ev)
        return evs

    @staticmethod
    def _aid(action_id: str | None) -> str:
        return action_id or uuid.uuid4().hex

    def debug_answers(self) -> list[int]:
        """Engine truth. For synthetic players and tests only; the child model never gets this."""
        cur = self.state.current
        return answer_slots(cur, self.state.objects) if cur else []

    # ---- view ----
    def view(self) -> SceneView:
        st = self.state
        v = SceneView(day=st.day, done=st.situations_done, per_day=st.per_day, phase=st.phase.value)
        if st.phase == Phase.CARDS and st.cards:
            v.previews = [{"index": i, "location": c.location, "items": len(c.scene), "word": c.word}
                          for i, c in enumerate(st.cards)]
        elif st.phase == Phase.SITUATION:
            c = st.current
            v.narration, v.hint = narrator.intro(c.id, c.word, c.location, st.current_first, c.word_kind)
            v.cards, v.tried = player_cards(c, st.objects), c.tried
        return v

    # ---- player actions ----
    def draw_cards(self, action_id: str | None = None) -> None:
        if self.state.cards is not None:
            return
        aid = self._aid(action_id)
        rng = self._rng("cards")
        sits, objs = self.director.offer(self.state.objects, self.state.day, rng, self.forbidden,
                                         self.state.requests)
        try:
            self._submit(OfferCards(action_id=aid, situations=sits, objects=objs))
        except RuleError:  # engine disagrees with the Director: use the validated template instead
            template = DirectorAgent(None, self.word_map)
            sits, objs = template.offer(self.state.objects, self.state.day, rng, self.forbidden,
                                      self.state.requests)
            self.director.last_source, self.director.last_error = "template", "engine rejected the proposal"
            self._submit(OfferCards(action_id=aid, situations=sits, objects=objs))

    def pick_card(self, index: int, action_id: str | None = None) -> None:
        self._submit(PickCard(action_id=self._aid(action_id), index=index))

    def _context(self):
        cur = self.state.current
        if cur is None:
            return None, None
        return cur, build_observation(cur, self.state.objects)

    def _kind(self, cur, slot: int) -> str:
        return self.state.objects[cur.scene[slot]].kind

    def show(self, slot: int, action_id: str | None = None) -> ActionResult:
        cur, obs = self._context()
        evs = self._submit(Show(action_id=self._aid(action_id), slot=slot))
        if not evs:
            return ActionResult(duplicate=True)
        right = evs[0].payload["was_right"]
        text = narrator.outcome("show", self._kind(cur, slot), cur.word, right, "player")
        return self._learn(Example(id=f"ex{len(self.buffer):04d}", day=self.state.day, source="show", obs=obs,
                                   target_slot=slot, weight=1.0, was_right=right), text, slot, right)

    def try_child(self, action_id: str | None = None) -> ActionResult:
        cur, obs = self._context()
        if cur is None:
            raise RuleError("wrong_phase", "no situation in progress")
        a = act(self.model, obs, self._rng("try"))
        evs = self._submit(Try(action_id=self._aid(action_id), slot=a.slot, probs=a.probs))
        if not evs:
            return ActionResult(duplicate=True)
        right = evs[0].payload["was_right"]
        text = narrator.outcome("try", self._kind(cur, a.slot), cur.word, right, "child")
        return ActionResult(narration=text, slot=a.slot, was_right=right, probs=a.probs)

    def praise(self, action_id: str | None = None) -> ActionResult:
        cur, obs = self._context()
        tried = cur.tried if cur else None
        evs = self._submit(Praise(action_id=self._aid(action_id)))
        if not evs:
            return ActionResult(duplicate=True)
        return self._learn(Example(id=f"ex{len(self.buffer):04d}", day=self.state.day, source="praise", obs=obs,
                                   target_slot=tried, weight=0.5, was_right=True), "You praise the child.", tried, True)

    def correct(self, slot: int, action_id: str | None = None) -> ActionResult:
        cur, obs = self._context()
        tried = cur.tried if cur else None
        evs = self._submit(Correct(action_id=self._aid(action_id), slot=slot))
        if not evs:
            return ActionResult(duplicate=True)
        right = evs[0].payload["was_right"]
        text = narrator.outcome("show", self._kind(cur, slot), cur.word, right, "player")
        return self._learn(Example(id=f"ex{len(self.buffer):04d}", day=self.state.day, source="correct", obs=obs,
                                   target_slot=slot, weight=1.0, rejected_slot=tried, was_right=right),
                           "You show the right one instead. " + text, slot, right)

    def skip(self, action_id: str | None = None) -> ActionResult:
        evs = self._submit(Skip(action_id=self._aid(action_id)))
        return ActionResult(duplicate=not evs, narration="You let it pass. Nothing is learned.")

    def _learn(self, ex: Example, text: str, slot, right) -> ActionResult:
        """Record the example, learn immediately, checkpoint, then log the LEARNED event."""
        self.save.append_example(ex)
        self.buffer.append(ex)
        rep = self.learner.learn(ex, self.buffer, self._rng("learn"))
        checkpoints.save(self.model, self.save.latest, opt=self.learner.opt,
                         meta={"n_learned": len(self.buffer), "events": len(self.engine.log)})
        self._submit(RecordLearned(action_id=f"learned-{ex.id}", report=rep.model_dump()))
        return ActionResult(narration=text, slot=slot, was_right=right, learn=rep)

    def end_day(self) -> dict:
        st = self.state
        if st.phase != Phase.EVENING:
            raise RuleError("wrong_phase", "the day is not over yet")
        known = {st.words[w] for w in st.picked_words}
        items = pick_daily(self.quiz, known, self._rng("quiz"), self.game.quiz_per_day)
        res = evaluate(self.model, self.model0, items)
        pool = evaluate(self.model, self.model0, [q for q in self.quiz if q.obs.name_token in known])
        res.update(day=st.day, pool_p_correct=pool["p_correct"], pool_greedy=pool["greedy"],
                   pool_untrained_p=pool["untrained_p"], pool_random=pool["random"], pool_n=pool["n"])
        self._submit(RecordQuiz(action_id=f"quiz-{st.day}", result=res))
        checkpoints.save(self.model, self.save.day_ckpt(st.day), meta={"day": st.day})
        self._submit(EndDay(action_id=f"endday-{st.day}"))
        return res

    # ---- "inside the child's head" ----
    def mind(self, compare_day: int | None = None, n: int = 30) -> dict:
        """Contrast-probe every word the child has met. With compare_day, also probe that day's snapshot so the
        panel can show what learning changed. Deterministic (fixed probe seed); never touches the model."""
        st = self.state
        known = {st.words[w] for w in st.picked_words}
        before = None
        if compare_day is not None:
            before = checkpoints.load(self.save.day_ckpt(compare_day))[0] if compare_day > 0 else self.model0
        out = {}
        for kind, (word, token) in self.word_map.items():
            if token not in known:
                continue
            seed = f"{self.seed}:mind:{token}"
            prefs = probe_word(self.model, token, random.Random(seed), n)
            items = [q for q in self.quiz if q.kind == kind]
            entry = {"kind": kind, "token": token, "accuracy": score(self.model, items)["greedy"], "prefs": prefs,
                     "pulls": pulls(prefs), "cues": top_cues(prefs)}
            if before is not None:
                bp = probe_word(before, token, random.Random(seed), n)
                entry["before"] = {"prefs": bp, "pulls": pulls(bp), "cues": top_cues(bp),
                                   "accuracy": score(before, items)["greedy"]}
            out[word] = entry
        return out
